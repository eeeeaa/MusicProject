# MusicProject
Music Streaming App project.
## Current name: CloudPlay

## TODO List:
- Media Player to playback retrieved files
- create flask app to create/add/delete/get from "my favorite" database
- create database server
- add playlist tabs
- log-in activity need work
- use Access token instead of API key

### Group members:
- Jom Thananont Chevaphatrakul
- Perth Sirikarn Yodvanich
- Perth Praewpun cheevamongkol
- Tantai Layluxsiri

