# MusicProject
Music Streaming App project.
## Current name: CloudPlay

## TODO List:
- Media Player to playback retrieved files
- create flask app to create/add/delete/get from "my favorite" database
- create database server
- add playlist tabs
- log-in activity need work
- use Access token instead of API key (implemented)

### Group members:
- Thananont Chevaphatrakul
- Sirikarn Yodvanich
- Praewpun cheevamongkol
- Tantai Layluxsiri

