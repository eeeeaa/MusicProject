About
=====

Authors
-------

.. include:: ../AUTHORS

License
-------
``youtube-dl-api-server`` and its documentation is released to the public domain:

.. literalinclude:: ../LICENSE
    :language: text
