youtube-dl-api-server
=====================

A REST API server for getting the info for videos from different sites, powered by `youtube-dl <http://rg3.github.io/youtube-dl/>`_.
The installation instructions and the documentation are available at `Read the Docs <https://youtube-dl-api-server.readthedocs.org/>`_.

About
-----

``youtube-dl-api-server`` is released to the public domain, read the `license <LICENSE>`_ for more info.
